<footer class="footer text-center text-sm-right">
    &copy; MARS Project
</footer>